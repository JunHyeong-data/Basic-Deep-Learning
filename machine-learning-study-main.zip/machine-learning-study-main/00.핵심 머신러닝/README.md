# 핵심 머신러닝 – 김성범 교수 강의 정리

<img width="2025" height="599" alt="image" src="https://github.com/user-attachments/assets/307f5809-a0c5-489e-81c6-94d790270012" />

> Data Science with Seoung Bum Kim  
> 핵심 머신러닝 강의 내용을 정리한 저장소입니다.

## 📌 강의 정보
- 강의명: 핵심 머신러닝
- 강의자: 김성범 교수 (산업경영공학부)
- 주제: 머신러닝의 핵심 개념, 모델, 데이터 기반 사고
